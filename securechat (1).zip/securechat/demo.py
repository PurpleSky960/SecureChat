"""End-to-end demo: Alice -> (server relay) -> Bob, then tampering and replay.

Run: python demo.py
The 'server' here is simulated by passing the JSON packet as a string; in the
real system Spring Boot relays it over WebSocket without seeing plaintext.
"""
import copy
from securechat_crypto.rsa_module import generate_rsa_keypair, rsa_oaep_encrypt, rsa_oaep_decrypt
from securechat_crypto.secure_random import generate_session_key
from securechat_crypto.packet import (create_packet, open_packet, PacketError,
                                      packet_to_json, packet_from_json, b64e, b64d)
from securechat_crypto.replay_guard import ReplayGuard

print("=== 1. Key generation & registration ===")
alice_priv, alice_pub = generate_rsa_keypair()
bob_priv, bob_pub = generate_rsa_keypair()
print("Alice and Bob generated RSA-2048 key pairs; public keys registered with server.")

print("\n=== 2. Session key establishment (RSA-OAEP) ===")
session_key = generate_session_key()
wrapped_key = rsa_oaep_encrypt(bob_pub, session_key)       # Alice -> Bob via server
bob_session_key = rsa_oaep_decrypt(bob_priv, wrapped_key)  # Bob unwraps
print("Wrapped session key (server sees this only):", b64e(wrapped_key)[:40], "...")
assert bob_session_key == session_key

print("\n=== 3. Alice sends 'Hello Bob!' ===")
packet = create_packet("Hello Bob!", session_key, alice_priv, "alice", "bob", "session-1")
wire = packet_to_json(packet)
print("What the server receives:\n", wire)

print("\n=== 4. Bob verifies and decrypts ===")
guard = ReplayGuard()
print("Bob reads:", open_packet(packet_from_json(wire), bob_session_key, alice_pub, guard))

print("\n=== 5. Tampering attack ===")
tampered = copy.deepcopy(packet_from_json(wire))
ct = bytearray(b64d(tampered["ciphertext"]))
ct[20] ^= 1
tampered["ciphertext"] = b64e(bytes(ct))
try:
    open_packet(tampered, bob_session_key, alice_pub, ReplayGuard())
except PacketError as e:
    print(e, "\nMESSAGE REJECTED")

print("\n=== 6. Replay attack ===")
try:
    open_packet(packet_from_json(wire), bob_session_key, alice_pub, guard)
except PacketError as e:
    print(e, "\nMESSAGE REJECTED")
