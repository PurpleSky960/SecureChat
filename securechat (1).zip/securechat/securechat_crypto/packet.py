"""Secure message packet: build (sender side) and open (receiver side).

Packet (JSON, all binary fields base64):
{
  "messageId", "senderId", "receiverId", "sessionId",
  "timestamp", "nonce", "ciphertext", "hmac", "signature"
}

Sender:  AES(enc_key) -> HMAC(mac_key) over metadata+ciphertext -> RSA-PSS over all but signature
Receiver: replay check -> verify HMAC -> verify signature -> AES decrypt
The server only ever sees this packet, never the plaintext.
"""
import base64
import json
import time

from .aes_module import aes_encrypt, aes_decrypt
from .hmac_module import derive_keys, compute_hmac, verify_hmac
from .signature_module import sign, verify_signature
from .secure_random import generate_nonce, generate_message_id
from .replay_guard import ReplayGuard, ACCEPTED

b64e = lambda b: base64.b64encode(b).decode()
b64d = lambda s: base64.b64decode(s)


class PacketError(Exception):
    """Raised when a packet is rejected. Message holds the reason."""


def _hmac_input(p: dict) -> bytes:
    """Canonical bytes covered by the HMAC (metadata + ciphertext)."""
    fields = [p["messageId"], p["senderId"], p["receiverId"], p["sessionId"],
              str(p["timestamp"]), p["nonce"], p["ciphertext"]]
    return "|".join(fields).encode()


def _signature_input(p: dict) -> bytes:
    """Canonical bytes covered by the signature (everything except signature)."""
    return _hmac_input(p) + b"|" + p["hmac"].encode()


def create_packet(plaintext: str, session_key: bytes, sender_private_key_pem: bytes,
                  sender_id: str, receiver_id: str, session_id: str) -> dict:
    enc_key, mac_key = derive_keys(session_key)
    packet = {
        "messageId": generate_message_id(),
        "senderId": sender_id,
        "receiverId": receiver_id,
        "sessionId": session_id,
        "timestamp": int(time.time()),
        "nonce": b64e(generate_nonce()),
        "ciphertext": b64e(aes_encrypt(enc_key, plaintext.encode("utf-8"))),
    }
    packet["hmac"] = b64e(compute_hmac(mac_key, _hmac_input(packet)))
    packet["signature"] = b64e(sign(sender_private_key_pem, _signature_input(packet)))
    return packet


def open_packet(packet: dict, session_key: bytes, sender_public_key_pem: bytes,
                replay_guard: ReplayGuard) -> str:
    """Verify and decrypt. Raises PacketError with the rejection reason."""
    required = ["messageId", "senderId", "receiverId", "sessionId",
                "timestamp", "nonce", "ciphertext", "hmac", "signature"]
    if any(k not in packet for k in required):
        raise PacketError("MALFORMED PACKET")

    # 1. Replay check
    status = replay_guard.check(packet["messageId"], packet["nonce"], packet["timestamp"])
    if status != ACCEPTED:
        raise PacketError(status)

    enc_key, mac_key = derive_keys(session_key)

    # 2. HMAC verification
    if not verify_hmac(mac_key, _hmac_input(packet), b64d(packet["hmac"])):
        raise PacketError("HMAC VERIFICATION FAILED")

    # 3. Signature verification
    if not verify_signature(sender_public_key_pem, _signature_input(packet),
                            b64d(packet["signature"])):
        raise PacketError("SIGNATURE VERIFICATION FAILED")

    # 4. AES decryption
    try:
        return aes_decrypt(enc_key, b64d(packet["ciphertext"])).decode("utf-8")
    except ValueError:
        raise PacketError("DECRYPTION FAILED")


def packet_to_json(packet: dict) -> str:
    return json.dumps(packet)


def packet_from_json(s: str) -> dict:
    return json.loads(s)
