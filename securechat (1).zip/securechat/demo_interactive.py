"""Interactive demo: Alice sends to Bob through an untrusted server.

Run: python demo_interactive.py
"""
import copy
from securechat_crypto.rsa_module import generate_rsa_keypair, rsa_oaep_encrypt, rsa_oaep_decrypt
from securechat_crypto.secure_random import generate_session_key
from securechat_crypto.packet import (create_packet, open_packet, PacketError,
                                      packet_to_json, packet_from_json, b64e, b64d)
from securechat_crypto.replay_guard import ReplayGuard

print("Setting up Alice and Bob (generating RSA keys)...")
alice_priv, alice_pub = generate_rsa_keypair()
bob_priv, bob_pub = generate_rsa_keypair()
session_key = generate_session_key()
bob_session_key = rsa_oaep_decrypt(bob_priv, rsa_oaep_encrypt(bob_pub, session_key))
print("Session key shared securely using RSA-OAEP.\n")

guard = ReplayGuard()      # Bob's replay protection
captured = None            # last packet the attacker saw on the wire


def deliver(packet):
    """Bob receives a packet from the server."""
    try:
        text = open_packet(packet, bob_session_key, alice_pub, guard)
        print(f"   >> Bob ACCEPTED the message: {text}")
    except PacketError as e:
        print(f"   >> Bob: {e}  -> MESSAGE REJECTED")


MENU = """
==================== MENU ====================
 1. Alice sends a message normally
 2. Alice sends a message, attacker MODIFIES it on the way (tamper)
 3. Attacker REPLAYS the last captured packet (replay attack)
 4. Quit
==============================================
"""

while True:
    print(MENU)
    choice = input("Choose 1, 2, 3 or 4: ").strip()

    if choice in ("1", "2"):
        text = input("Alice, type your message: ").strip() or "Hello Bob!"
        packet = create_packet(text, session_key, alice_priv, "alice", "bob", "session-1")
        captured = copy.deepcopy(packet)   # attacker copies it from the wire
        print("\n   Server sees only (no plaintext):")
        print("   ciphertext:", packet["ciphertext"])
        print("   hmac      :", packet["hmac"])
        print("   signature :", packet["signature"][:40], "...")
        if choice == "2":
            ct = bytearray(b64d(packet["ciphertext"]))
            ct[-1] ^= 1
            packet["ciphertext"] = b64e(bytes(ct))
            print("\n   ATTACKER flipped one bit of the ciphertext in transit.")
        deliver(packet)

    elif choice == "3":
        if captured is None:
            print("\n   Nothing captured yet. Send a message first (option 1).")
        else:
            print("\n   ATTACKER re-sends the previously captured packet.")
            deliver(copy.deepcopy(captured))

    elif choice == "4":
        print("Goodbye.")
        break
    else:
        print("   Please type 1, 2, 3 or 4.")
