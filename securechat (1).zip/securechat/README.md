# SecureChat – Python Security Layer (Evaluation 1)

```
securechat_crypto/
  secure_random.py    session key, nonce, salt, message ID
  aes_module.py       AES-256-CBC (confidentiality), IV prepended
  rsa_module.py       RSA-2048 keygen + RSA-OAEP (key establishment)
  hmac_module.py      HMAC-SHA256 + HKDF key separation (integrity)
  signature_module.py SHA-256 + RSA-PSS (sender authenticity)
  replay_guard.py     messageId + nonce + timestamp window (replay protection)
  packet.py           secure packet create/open pipeline
tests/test_crypto.py  AES, HMAC, PSS, OAEP, replay, tamper tests
demo.py               Alice -> Bob end-to-end + tamper + replay
```

## Run
```
pip install -r requirements.txt
python -m pytest tests -v -s     # test output with PASS/FAIL evidence
python demo.py                   # fixed demo
python demo_interactive.py       # type your own message, tamper, replay
python benchmark.py              # timing and packet-size numbers
```

## Design notes
- Encrypt-then-MAC: HMAC covers all metadata + ciphertext; signature covers everything except itself (including the HMAC).
- One session key is split via HKDF into separate encryption and MAC keys.
- Private keys and plaintext session keys are never sent to or stored by the server.
- ReplayGuard is in-memory; the Spring Boot side can add DB-backed checks later.
