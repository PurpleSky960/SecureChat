"""Timing and packet-size measurements for the report (Section 4.2). Run: python benchmark.py"""
import time, statistics
from securechat_crypto.rsa_module import generate_rsa_keypair, rsa_oaep_encrypt, rsa_oaep_decrypt
from securechat_crypto.secure_random import generate_session_key
from securechat_crypto.packet import create_packet, open_packet, packet_to_json
from securechat_crypto.replay_guard import ReplayGuard

def avg_ms(f, n=100):
    xs = []
    for _ in range(n):
        t = time.perf_counter(); f(); xs.append((time.perf_counter() - t) * 1000)
    return round(statistics.mean(xs), 2)

priv, pub = generate_rsa_keypair()
key = generate_session_key()
wrapped = rsa_oaep_encrypt(pub, key)
print("RSA-OAEP wrap   (ms):", avg_ms(lambda: rsa_oaep_encrypt(pub, key)))
print("RSA-OAEP unwrap (ms):", avg_ms(lambda: rsa_oaep_decrypt(priv, wrapped)))
print("Create packet   (ms):", avg_ms(lambda: create_packet("Hello Bob!", key, priv, "a", "b", "s")))
packets = iter([create_packet("Hello Bob!", key, priv, "a", "b", "s") for _ in range(100)])
guard = ReplayGuard()
print("Open packet     (ms):", avg_ms(lambda: open_packet(next(packets), key, pub, guard)))
print("Packet size, 10 chars  :", len(packet_to_json(create_packet("Hello Bob!", key, priv, "a", "b", "s"))), "bytes")
print("Packet size, 1000 chars:", len(packet_to_json(create_packet("x" * 1000, key, priv, "a", "b", "s"))), "bytes")
