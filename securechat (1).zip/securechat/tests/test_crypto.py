"""Evaluation 1 test suite: run with `python -m pytest tests -v -s`."""
import copy
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from securechat_crypto.aes_module import aes_encrypt, aes_decrypt
from securechat_crypto.rsa_module import generate_rsa_keypair, rsa_oaep_encrypt, rsa_oaep_decrypt
from securechat_crypto.hmac_module import derive_keys, compute_hmac, verify_hmac
from securechat_crypto.signature_module import sign, verify_signature, sha256
from securechat_crypto.secure_random import (generate_session_key, generate_nonce,
                                             generate_salt, generate_message_id)
from securechat_crypto.replay_guard import ReplayGuard
from securechat_crypto.packet import create_packet, open_packet, PacketError, b64e, b64d


@pytest.fixture(scope="module")
def alice_keys():
    return generate_rsa_keypair()


def test_1_aes_roundtrip():
    key = generate_session_key()
    ct = aes_encrypt(key, b"Hello Bob")
    pt = aes_decrypt(key, ct)
    print(f"\nTest 1 AES  | input=Hello Bob | encrypted={ct.hex()[:24]}... | decrypted={pt.decode()} | PASS")
    assert pt == b"Hello Bob"
    assert ct != aes_encrypt(key, b"Hello Bob")  # random IV -> different ciphertext


def test_2_hmac_valid_and_tampered():
    _, mac_key = derive_keys(generate_session_key())
    ct = aes_encrypt(generate_session_key(), b"data")
    tag = compute_hmac(mac_key, ct)
    tampered = bytearray(ct)
    tampered[-1] ^= 1
    valid = verify_hmac(mac_key, ct, tag)
    bad = verify_hmac(mac_key, bytes(tampered), tag)
    print(f"\nTest 2 HMAC | normal={'VALID' if valid else 'FAIL'} | tampered={'VALID' if bad else 'FAIL'}")
    assert valid and not bad


def test_3_signature_valid_and_modified(alice_keys):
    priv, pub = alice_keys
    msg = b"Hello Bob"
    sig = sign(priv, msg)
    ok = verify_signature(pub, msg, sig)
    bad = verify_signature(pub, b"Hello Eve", sig)
    print(f"\nTest 3 RSA-PSS | original={'VALID' if ok else 'INVALID'} | modified={'VALID' if bad else 'INVALID'}")
    assert ok and not bad
    assert len(sha256(msg)) == 32


def test_4_rsa_oaep_session_key(alice_keys):
    priv, pub = alice_keys
    session_key = generate_session_key()
    wrapped = rsa_oaep_encrypt(pub, session_key)
    unwrapped = rsa_oaep_decrypt(priv, wrapped)
    print(f"\nTest 4 RSA-OAEP | wrapped={wrapped.hex()[:24]}... | recovered==original: {unwrapped == session_key}")
    assert unwrapped == session_key


def test_5_replay_detection(alice_keys):
    priv, pub = alice_keys
    key = generate_session_key()
    guard = ReplayGuard()
    pkt = create_packet("Hello Bob!", key, priv, "alice", "bob", "s1")
    assert open_packet(pkt, key, pub, guard) == "Hello Bob!"
    with pytest.raises(PacketError) as e:
        open_packet(pkt, key, pub, guard)
    print(f"\nTest 5 Replay | first=ACCEPTED | second={e.value}")
    assert "REPLAY" in str(e.value)


def test_6_tampered_packet_rejected(alice_keys):
    priv, pub = alice_keys
    key = generate_session_key()
    pkt = create_packet("Hello Bob!", key, priv, "alice", "bob", "s1")
    bad = copy.deepcopy(pkt)
    ct = bytearray(b64d(bad["ciphertext"]))
    ct[20] ^= 1
    bad["ciphertext"] = b64e(bytes(ct))
    with pytest.raises(PacketError) as e:
        open_packet(bad, key, pub, ReplayGuard())
    print(f"\nTest 6 Tamper | {e.value}")
    assert "HMAC" in str(e.value)


def test_7_wrong_sender_signature_rejected(alice_keys):
    priv, pub = alice_keys
    mallory_priv, _ = generate_rsa_keypair()
    key = generate_session_key()
    pkt = create_packet("Hello Bob!", key, mallory_priv, "alice", "bob", "s1")
    with pytest.raises(PacketError) as e:
        open_packet(pkt, key, pub, ReplayGuard())
    print(f"\nTest 7 Forged sender | {e.value}")
    assert "SIGNATURE" in str(e.value)


def test_8_expired_timestamp_rejected(alice_keys):
    priv, pub = alice_keys
    key = generate_session_key()
    pkt = create_packet("Hello Bob!", key, priv, "alice", "bob", "s1")
    pkt["timestamp"] -= 3600
    with pytest.raises(PacketError):
        open_packet(pkt, key, pub, ReplayGuard())


def test_9_secure_random_values():
    assert len(generate_session_key()) == 32
    assert generate_nonce() != generate_nonce()
    assert len(generate_salt()) == 16
    assert generate_message_id() != generate_message_id()
